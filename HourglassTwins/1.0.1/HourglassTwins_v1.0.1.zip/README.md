# 沙漏双星 HourglassTwins

![](https://cdn.jsdelivr.net/gh/hjthjthjt/HourglassTwins/screenshot.png)

⏳那个星系的第一个 WordPress 主题⌛

因为很喜欢 Outer Wilds 里的 `沙漏双星`，所以以它为名。

主要是自用，以简单为主。

基于 [kevquirk/quirk-wordpress-theme](https://github.com/kevquirk/quirk-wordpress-theme) 开发。

Demo： [https://jakting.com](https://jakting.com)

# 下载 & 更新日志
详见每个版本文件夹：[https://cdn.jsdelivr.net/gh/hjthjthjt/hjthjthjt/HourglassTwins/](https://cdn.jsdelivr.net/gh/hjthjthjt/hjthjthjt/HourglassTwins/)

